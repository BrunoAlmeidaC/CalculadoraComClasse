public class Calculadora {
    private double soma(double num1, double num2) {
        return num1 + num2;
    }

    private double subtracao(double num1, double num2) {
        return num1 - num2;
    }

    private double multiplicacao(double num1, double num2) {
        return num1 * num2;
    }

    private double divisao(double num1, double num2) {
        if (num2 != 0) {
            return num1 / num2;
        } else {
            return Double.NaN;
        }
    }

    public double calcular(double num1, double num2, char operacao) {
        switch (operacao) {
            case '+':
                return soma(num1, num2);
            case '-':
                return subtracao(num1, num2);
            case '*':
                return multiplicacao(num1, num2);
            case '/':
                return divisao(num1, num2);
            default:
                return Double.NaN;
        }
    }
}
