import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Calculadora calculadoraComClasse = new Calculadora();

        Scanner input = new Scanner(System.in);

        double num1, num2, resultado;
        char operacao;

        System.out.print("Digite o primeiro número: ");
        num1 = input.nextDouble();

        System.out.print("Digite o segundo número: ");
        num2 = input.nextDouble();

        System.out.print("Digite a operação (+, -, *, /): ");
        operacao = input.next().charAt(0);

        resultado = calculadoraComClasse.calcular(num1, num2, operacao);

        System.out.println("Resultado da operação: " + resultado);
    }
}
